from django.apps import AppConfig


class TaxiApplicationConfig(AppConfig):
    name = 'taxi_application'
